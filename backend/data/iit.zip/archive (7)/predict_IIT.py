import pandas as pd

def generate_preferred_college_list(student_rank, student_category, student_branch, data, preferred_cities):
    preferred_colleges = []
    
    # Category to Percentile column mapping
    category_column_mapping = {
        "OPEN neutral": "OPEN neutral",
        "OPEN female": "OPEN female",
        "OPEN(PWD)": "OPEN(PWD)",
        "EWS neutral": "EWS neutral",
        "EWS female": "EWS female",
        "EWS(PWD)": "EWS(PWD)",
        "OBC neutral": "OBC neutral",
        "OBC female": "OBC female",
        "OBC(PWD)": "OBC(PWD)",
        "SC neutral": "SC neutral",
        "SC female": "SC female",
        "SC(PWD)": "SC(PWD)",
        "ST neutral": "ST neutral",
        "ST female": "ST female",
        "ST(PWD)": "ST(PWD)",
    }
    
    if student_category not in category_column_mapping:
        print(f"Invalid category: {student_category}")
        return []

    category_rank_column = category_column_mapping[student_category]

    for _, row in data.iterrows():
        college_name = row['College Name']
        branch_name = row['Branch']
        city = row['City']
        cutoff_rank = row[category_rank_column]

        # Skip colleges not in preferred cities
        if preferred_cities and city not in preferred_cities:
            continue  

        # Skip if cutoff rank is not met
        if pd.isnull(cutoff_rank) or student_rank > cutoff_rank:
            continue  

        # Skip if branch does not match (if branch is provided)
        if student_branch and branch_name.lower() != student_branch.lower():
            continue

        # Add the college to the list
        preferred_colleges.append({
            "college": college_name,
            "branch": branch_name,
            "city": city,
            "cutoff_rank": cutoff_rank
        })

    print(f"Preferred colleges: {preferred_colleges}")
    return preferred_colleges
