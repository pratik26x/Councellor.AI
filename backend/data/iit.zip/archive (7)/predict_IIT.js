document.getElementById('prediction-form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent default form submission

  const formData = new FormData(this); // Create a FormData object from the form

  fetch('/predict_IIT', {
      method: 'POST',
      body: formData
  })
  .then(response => response.json())
  .then(data => {
      const resultDiv = document.getElementById('result');
      resultDiv.innerHTML = ''; // Clear previous results

      if (data.error) {
          resultDiv.innerHTML = `<p>${data.error}</p>`;
          return;
      }

      if (data.length === 0) {
          resultDiv.innerHTML = '<p>No colleges found that match your criteria.</p>';
      } else {
          const resultList = document.createElement('ul');
          data.forEach(college => {
              const listItem = document.createElement('li');
              listItem.textContent = `${college.college} (${college.branch}) - ${college.city}, Cutoff Rank: ${college.cutoff_rank}`;
              resultList.appendChild(listItem);
          });
          resultDiv.appendChild(resultList);
      }
  })
  .catch(error => {
      console.error('Error:', error);
      const resultDiv = document.getElementById('result');
      resultDiv.innerHTML = '<p>Error fetching the data. Please try again.</p>';
  });
});
