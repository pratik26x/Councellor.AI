from flask import Flask, request, jsonify, send_from_directory
import pandas as pd
from predict_IIT import generate_preferred_college_list  # Import your function

app = Flask(__name__)

# Load the college data once when the app starts
data = pd.read_csv('college_IIT.csv')

@app.route('/')
def home():
    return send_from_directory('.', 'predict_IIT.html')

@app.route('/predict_IIT', methods=['POST'])
def predict_IIT():
    # Get data from the form
    student_rank = request.form['rank']
    student_category = request.form['category']
    student_branch = request.form.get('branch', None)
    if student_branch == '':
        student_branch = None
    preferred_cities_input = request.form['preferred_cities']
    preferred_cities = [city.strip() for city in preferred_cities_input.split(',') if city.strip()]

    # Debugging input data
    print(f"Received data: rank={student_rank}, category={student_category}, branch={student_branch}, cities={preferred_cities}")

    # Generate the preferred college list
    try:
        preferred_colleges = generate_preferred_college_list(
            student_rank, student_category, student_branch, data, preferred_cities
        )
        print(f"Generated preferred colleges: {preferred_colleges}")
    except Exception as e:
        print(f"Error generating college list: {e}")
        return jsonify({"error": "Something went wrong while processing your request."})

    # Return results as JSON
    return jsonify(preferred_colleges)

@app.route('/<path:filename>', methods=['GET'])
def serve_file(filename):
    return send_from_directory('.', filename)

if __name__ == '__main__':
    app.run(debug=True)
